package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;



@Service
public class InventoryServiceImpl {

	@Autowired
	private InventoryRepository inventoryRepository;

	public ResponseEntity<Inventory> addInventory(Inventory inventoryData) {
		return new ResponseEntity<>(inventoryRepository.save(inventoryData), HttpStatus.CREATED);
	}
	

	public ResponseEntity<String> deleteInventory(Integer id) {
		if (!inventoryRepository.existsById(id)) {
			throw new RuntimeException("Id not found");
		}
		inventoryRepository.deleteById(id);
		return new ResponseEntity<String>("Deleted" , HttpStatus.OK);
	}

	
	
	public ResponseEntity<String> updateInventory(Integer id, Inventory inventoryData) {
		if (!inventoryRepository.existsById(id)) {
			throw new RuntimeException("Id not found");		}
		inventoryData.setInventoryid(id);
		 inventoryRepository.save(inventoryData);
		return new ResponseEntity<String>("Updated" , HttpStatus.OK);
	}

	public ResponseEntity<Inventory> getInventory(Integer id) {
	 	Optional<Inventory> resultOptional = inventoryRepository.findById(id);
	 	if (!resultOptional.isPresent()) {
	 		throw new RuntimeException("Id not found");	 	}
	 	return new ResponseEntity<Inventory>(inventoryRepository.save(resultOptional.get()), HttpStatus.OK);
	}


	public List<Inventory> getAllInventory() {
		
		return inventoryRepository.findAll();
	}
}
