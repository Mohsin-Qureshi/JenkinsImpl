package com.example.demo;

import javax.persistence.*;

@Entity
@SequenceGenerator(name = "inventory_sequence", sequenceName = "inventory_sequence", initialValue = 1003, allocationSize = 1)
public class Inventory {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "inventory_sequence")
	int inventoryId;
	int productId;
	int quantity;
	
	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Inventory(int inventoryid, int productId, int quantity) {
		super();
		this.inventoryId = inventoryid;
		this.productId = productId;
		this.quantity = quantity;
	}

	public int getInventoryid() {
		return inventoryId;
	}

	public void setInventoryid(int inventoryid) {
		this.inventoryId = inventoryid;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "InventoryModel [inventoryid=" + inventoryId + ", productId=" + productId + ", quantity=" + quantity
				+ "]";
	}
	
	
	
}
