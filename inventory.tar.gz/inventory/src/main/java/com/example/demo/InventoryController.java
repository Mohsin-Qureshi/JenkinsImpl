package com.example.demo;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/inventory")
public class InventoryController {

	@Autowired
	private InventoryServiceImpl inventoryService;

	@Value("${message}")
    private String message;

    @GetMapping
        public String getMessage()
        {
        return this.message;
        }
	
    @PostMapping
	public ResponseEntity<Inventory> addInventory(@RequestBody Inventory inventoryData) {

		return inventoryService.addInventory(inventoryData);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteInventory(@PathVariable("id") Integer id) {
		return inventoryService.deleteInventory(id);
	}

	@PutMapping("/{id}")
	public ResponseEntity<String> updateInventory(@PathVariable("id") Integer id, @RequestBody Inventory inventoryData) {
		return inventoryService.updateInventory(id, inventoryData);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Inventory> getInventory(@PathVariable("id") Integer id) {
		return inventoryService.getInventory(id);
	}
	@GetMapping("/all")
	public ResponseEntity<List<Inventory>> getAllInventory() {
		return ResponseEntity.ok(inventoryService.getAllInventory()) ;
	}
}
