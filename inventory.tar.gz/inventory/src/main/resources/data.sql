insert into Inventory (inventory_Id,product_Id,quantity) values (1001,1001,30);
insert into Inventory (inventory_Id,product_Id,quantity) values (1002,1002,40);
