package com.example.demo;



import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;



import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class InventoryControllerTest {

	@InjectMocks
	InventoryController inventoryController;

	@Mock
	InventoryServiceImpl inventoryService;

	Inventory inventory = new Inventory(1, 10, 100);

	@Test
	public void testAddInventory() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

		when(inventoryService.addInventory(any(Inventory.class)))
				.thenReturn(new ResponseEntity<>(inventory, HttpStatus.CREATED));

		ResponseEntity<Inventory> responseEntity = inventoryController.addInventory(inventory);

		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(201);
		assertThat(responseEntity.getBody().getProductId()).isEqualTo(10);
		assertThat(responseEntity.getBody().getQuantity()).isEqualTo(100);
	}

	@Test
	public void testUpdateInventory() {
		Integer inventoryId = 1;
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

		when(inventoryService.updateInventory(anyInt(), any(Inventory.class)))
				.thenReturn(new ResponseEntity<String>("Updated", HttpStatus.OK));

		ResponseEntity<String> responseEntity = inventoryController.updateInventory(inventoryId, inventory);

		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
		assertThat(responseEntity.getBody()).isEqualTo("Updated");
		
	}

	@Test
	public void testGetInventory() {
		Integer inventoryId = 1;
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

		when(inventoryService.getInventory(anyInt())).thenReturn(new ResponseEntity<>(inventory, HttpStatus.OK));

		ResponseEntity<Inventory> responseEntity = inventoryController.getInventory(inventoryId);

		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
		assertThat(responseEntity.getBody().getProductId()).isEqualTo(10);
		assertThat(responseEntity.getBody().getQuantity()).isEqualTo(100);
	}

	@Test
	public void testDeleteInventory() {
		Integer inventotyId = 1;
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

		when(inventoryService.deleteInventory(inventotyId)).thenReturn(new ResponseEntity<String>("Deleted", HttpStatus.OK));

		ResponseEntity<String> responseEntity = inventoryController.deleteInventory(inventotyId);

		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}

}
