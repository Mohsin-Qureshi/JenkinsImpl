package com.example.demo;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;



import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class ProductControllerTest {
	
		@InjectMocks
	    ProductRestController productController;
		
	  @Mock	  
	  ProductServiceimpl productService;
	  
	  
	  
	  @Test
	  public void testAddProduct()
	  {
		  Product product = new Product(1,"Pen","writing",5);
		  
		  MockHttpServletRequest request = new MockHttpServletRequest();
	        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

	        when(productService.saveProduct(any(Product.class))).thenReturn(product);
	        
	        ResponseEntity<Product> responseEntity = productController.addProduct(product);

	        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.CREATED);
	        assertThat(responseEntity.getBody().getProductId()).isEqualTo(1);

	  }
	  
	  @Test
	  public void testUpdateProduct()
	  {
		   Product product = new Product(1,"PEN","writing",15);
		  
		  MockHttpServletRequest request = new MockHttpServletRequest();
	        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

	        when(productService.updateProduct( 1, product )).thenReturn(product);
	        
	        ResponseEntity<Product> responseEntity = productController.updateProduct(product,1);

	        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
	        assertThat(responseEntity.getBody().getProductPrice()).isEqualTo(15);

	  }
	  
	  @Test
	    void testDeleteProduct() {
	        ResponseEntity<String> response = productController.deleteProduct(1);
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        verify(productService).deleteProduct(1);
	    }
	  
	  @Test
	    void testSearchProduct() {
		  
		  Product product = new Product(1,"PEN","writing",15);
			 
		    MockHttpServletRequest request = new MockHttpServletRequest();
	        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

	        when(productService.getProductById(anyInt())).thenReturn(product);

	        ResponseEntity<Product> response = productController.getProductByid(1);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals(product, response.getBody());
	        verify(productService).getProductById(1);
	    }

}
