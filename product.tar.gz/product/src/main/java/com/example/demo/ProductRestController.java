package com.example.demo;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@CrossOrigin("http://localhost:4200/")
@RefreshScope
@RestController
@RequestMapping("/product")
public class ProductRestController {


	private ProductServiceimpl productService;

	public ProductRestController() {
		
	}
	@Autowired
	public ProductRestController(ProductServiceimpl productService) {
		this.productService = productService;
	}
	
	@Value("${message}")
	private String message;
	
	@GetMapping
		public String getMessage()
		{
		return this.message;
		}
	
	@PostMapping
	public ResponseEntity<Product> addProduct(Product product)
	{
		Product addProduct=productService.saveProduct(product);
		return ResponseEntity.status(HttpStatus.CREATED).body(addProduct);
	}
	
	@DeleteMapping("/{productId}")
	public ResponseEntity<String> deleteProduct(@PathVariable int productId)
	{
		productService.deleteProduct(productId);
		return ResponseEntity.status(HttpStatus.OK).body("Deleted product id no "+productId+"");
		
	}
	
	@PutMapping("/{productId}")
	public ResponseEntity<Product> updateProduct(@RequestBody Product product,@PathVariable int productId)
	{
		productService.updateProduct(productId,product);
		return ResponseEntity.status(HttpStatus.OK).body(product);
	}
	
	@GetMapping("/{productId}")
	public ResponseEntity<Product> getProductByid(@PathVariable int productId)
	{
		Product product = productService.getProductById(productId);
		return ResponseEntity.status(HttpStatus.OK).body(product);
	}
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getProducts()
	{
		List<Product> products=productService.getProduct();
		return ResponseEntity.status(HttpStatus.OK).body(products);
	}
}
