package com.example.demo;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class ProductServiceimpl {
		
	@Autowired
	ProductRepository productRepo;
	
	public ProductServiceimpl() {
		// TODO Auto-generated constructor stub
	}

	
	 public List<Product> getProduct() {
        List<Product> products = productRepo.findAll();
        return products;
    }

	
	 public Product getProductById(@PathVariable int id) {
        Product product = productRepo.findById(id).
        		orElseThrow(() -> new RuntimeException("Product with ID " + id + " not found"));;
        return product;
    }

	
	 public Product saveProduct(@RequestBody Product product) {
        Product savedProduct = productRepo.save(product);
        return savedProduct;
    }
	
	
	 public Product updateProduct(@PathVariable int id, @RequestBody Product product) {
		
	        if (!productRepo.existsById(id)) {
	        	throw new RuntimeException("Product with ID " + id + " not found");
	        }
	        product.setProductId(id);
	        Product updatedProduct = productRepo.save(product);
	        return updatedProduct;
	    }

	
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		  if (!productRepo.existsById(id)) {
			  throw new RuntimeException("Product with ID " + id + " not found");
	        }
		  productRepo.deleteById(id);
	}
}
