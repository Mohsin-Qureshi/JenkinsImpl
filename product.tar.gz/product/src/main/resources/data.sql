insert into product (product_id,product_name,product_description,product_price) values (1001,'SAMSUNG','MOBILE',10000);
insert into product (product_id,product_name,product_description,product_price) values (1002,'VIVO','MOBILE',11000);
